export const Sample=()=>{
return (
    <div>
        hello web!
    </div>
)
}