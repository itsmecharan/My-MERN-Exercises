import React from 'react'

export default function Contactadmin() {
    return (
        <div>
            <div className="contactadmin">
                Mail: admin@eofferweb.com <br /> <br />
                Phone Number: 9638527410
            </div>
        </div>
    )
}
